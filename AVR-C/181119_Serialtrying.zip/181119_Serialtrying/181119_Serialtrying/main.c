/*
 * 181119_Serialtrying.c
 *
 * Created: 18.11.2019 14:20:45
 * Author : Num10
 *
 * Just trying to get Serial Communications to work... let's see if we can do it
 */ 

#include <avr/io.h>
#include <string.h>
#define F_CPU 16000000UL
#include <util/delay.h>

#define BAUD0 9600
// Value for UBRRn Register at BAUD
#define MYUBRR0 (F_CPU/16/BAUD0-1)
// Max elements in Strings receivable
#define MAX_CHAR 50


unsigned char Serial0_rx_char(){
	while (!(UCSR0A & (1<<RXC0))){
	}
	// Return Value currently in the Data Register
	return UDR0;
}

unsigned char *Serial0_rx_str(unsigned int max){
	// Set USART to Receiving Mode
	UCSR0B &= 0b11101111;
	UCSR0B |= (1 << RXEN0);

	unsigned char RXc;
	static unsigned char RXstr[MAX_CHAR];
	unsigned int i = 0;

	// As long as received Char isn't '\0' continue to receive
	while(RXc != '\0' && i < max-1){
		RXstr[i] = Serial0_rx_char();
		i++;
	}
	// Terminate the String with '\0'
	RXstr[i+1] = '\0';
	return *RXstr;
}

void Serial0_tx_char(unsigned char c){
	while(!(UCSR0A & (1<<UDRE0))){
	}
	// Send char c
	UDR0 = c;
}

void Serial0_tx_str(char *s){
	// Set USART to Transmitting Mode
	UCSR0B &= 0b11110111;
	UCSR0B |= (1 << TXEN0);

	while(*s){
		Serial0_tx_char(*s);
		s++;
	}
}

void Serial0_init(unsigned int ubrr){
	UBRR0 = 0;
	UCSR0B = 0;
	UCSR0C = 0;

	// Set UBRRn for BAUD
	UBRR0 = ubrr;
	// Enable Receiver and/or Transmitter (Here only TX)
	UCSR0B |= (1 << TXEN0);
	// Set Modes (Here Asynchronous modes, no parity, 8 data bits, 1 stop bit)
	UCSR0C |= (1 << UCSZ01) | (1 << UCSZ00);
}

int main(void)
{

	Serial0_init(MYUBRR0);
	
    while (1) 
    {
		//Serial0_tx_str("Hello, I'm ATMega2560!\n");
		//_delay_ms(500);

		unsigned char str[MAX_CHAR];
		static unsigned int max = MAX_CHAR;

		if(!(UCSR0A & (1<<RXC0))){
			 str = Serial0_rx_str(max);
		}



    }

	return 0;
}

